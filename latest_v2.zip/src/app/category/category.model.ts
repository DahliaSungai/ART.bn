export class categories {
    constructor(public id: string,
                public imageUrl: string,
                public title: string){}
}

